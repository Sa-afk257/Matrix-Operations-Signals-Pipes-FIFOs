#ifndef __OPERATION_H_
#define __OPERATION_H_

int Delete_Matrix();
int Modify_Matrix();
MatrixMemory *pool_operation(MatrixMemory *A, MatrixMemory *B, int op, char *op_name);
MatrixMemory *add_matrix(MatrixMemory *A, MatrixMemory *B) ;
MatrixMemory *sub_matrix(MatrixMemory *A, MatrixMemory *B) ;
MatrixMemory *multiply_matrices(MatrixMemory *A, MatrixMemory *B);
double Determinant(MatrixMemory *M);
double det_gauss_omp(const double *data, int n);
int eigenpair(MatrixMemory *M, double *lambda_out, double *evec_out);
double eigenvalue(MatrixMemory *M);
double compute_dominant_eigenpair(const double *A, int n, double *vec_out);

#endif
