
#ifdef _OPENMP
#include <omp.h>
#endif

#include "menu.h"
#include "header.h"
#include "MatrixMemory.h"
#include "RegisteryMatrixInMemory.h"
#include "FileIO.h"
#include "operation.h"
#include "processPool.h"
#include <math.h>

/* ============================================================
 *  Delete a matrix by ID
 * ============================================================ */
int Delete_Matrix(void) {
    int ID = 0, ch;

    if (Register_count() == 0) {
        printf("No matrices in memory.\n");
        return -1;
    }

    Register_ListOfMatrices();

    printf("Enter matrix ID to delete: ");
    if (scanf("%d", &ID) != 1) {
        printf("Invalid ID matrix\n");
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return -1;
    }
    while ((ch = getchar()) != '\n' && ch != EOF) {}   // flush

    MatrixMemory *m = Register_Find(ID);
    if (!m) {
        printf("Matrix ID %d not found\n", ID);
        return -1;
    }

    if (Register_Delete(ID) == 0) {
        printf("Delete Matrix (ID:%d). Completed\n", ID);
    } else {
        printf("Delete Matrix (ID:%d). Not Completed\n", ID);
    }

    return 0;
}

/* ============================================================
 *  Modify a matrix (row / column / single element)
 * ============================================================ */
int Modify_Matrix(void) {
    int ID = 0, ch, choice;

    if (Register_count() == 0) {
        printf("No matrices in memory.\n");
        return -1;
    }

    Register_ListOfMatrices();

    printf("Enter matrix ID to modify: ");
    if (scanf("%d", &ID) != 1) {
        printf("Invalid ID matrix\n");
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return -1;
    }
    while ((ch = getchar()) != '\n' && ch != EOF) {}   // flush

    MatrixMemory *m = Register_Find(ID);
    if (!m) {
        printf("Matrix ID %d not found\n", ID);
        return -1;
    }

    printf("1) Modify Full Row\n");
    printf("2) Modify Full Column\n");
    printf("3) Modify Particular value\n");
    printf("Enter your choice: ");

    if (scanf("%d", &choice) != 1) {
        printf("Input error.\n");
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return -1;
    }
    while ((ch = getchar()) != '\n' && ch != EOF) {}   // flush

    switch (choice) {
    case 1: {  // Modify full row
        int r;
        printf("Enter row index (1 .. %d): ", m->row);
        if (scanf("%d", &r) != 1) {
            printf("Input Error\n");
            while ((ch = getchar()) != '\n' && ch != EOF) {}
            return -1;
        }
        while ((ch = getchar()) != '\n' && ch != EOF) {}

        if (r < 1 || r > m->row) {
            printf("Out of range\n");
            return -1;
        }

        printf("Enter %d values for row %d (separated by space): ", m->col, r);
        for (int c = 0; c < m->col; ++c) {
            double value;
            if (scanf("%lf", &value) != 1) {
                printf("Input Error\n");
                while ((ch = getchar()) != '\n' && ch != EOF) {}
                return -1;
            }
            m->data[(r - 1) * m->col + c] = value;
        }
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        printf("Row %d Updated.\n", r);
        return 0;
    }

    case 2: {  // Modify full column
        int c;
        printf("Enter column index (1 .. %d): ", m->col);
        if (scanf("%d", &c) != 1) {
            printf("Input Error\n");
            while ((ch = getchar()) != '\n' && ch != EOF) {}
            return -1;
        }
        while ((ch = getchar()) != '\n' && ch != EOF) {}

        if (c < 1 || c > m->col) {
            printf("Out of range\n");
            return -1;
        }

        printf("Enter %d values for column %d (separated by space): ", m->row, c);
        for (int r = 0; r < m->row; ++r) {
            double value;
            if (scanf("%lf", &value) != 1) {
                printf("Input Error\n");
                while ((ch = getchar()) != '\n' && ch != EOF) {}
                return -1;
            }
            m->data[r * m->col + (c - 1)] = value;
        }
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        printf("Column %d Updated.\n", c);
        return 0;
    }

    case 3: {  // Modify single element
        int r, c;
        printf("Enter row (1..%d) and column (1..%d): ", m->row, m->col);
        if (scanf("%d %d", &r, &c) != 2) {
            printf("Input error.\n");
            while ((ch = getchar()) != '\n' && ch != EOF) {}
            return -1;
        }
        while ((ch = getchar()) != '\n' && ch != EOF) {}

        if (r < 1 || r > m->row || c < 1 || c > m->col) {
            printf("Out of range.\n");
            return -1;
        }

        double oldvalue = m->data[(r - 1) * m->col + (c - 1)];
        printf("Current value at (%d,%d) = %g. Enter new value: ", r, c, oldvalue);
        double newvalue;
        if (scanf("%lf", &newvalue) != 1) {
            printf("Input error.\n");
            while ((ch = getchar()) != '\n' && ch != EOF) {}
            return -1;
        }
        while ((ch = getchar()) != '\n' && ch != EOF) {}

        m->data[(r - 1) * m->col + (c - 1)] = newvalue;
        printf("Value updated.\n");
        return 0;
    }

    default:
        printf("Invalid choice\n");
        return -1;
    }

    return -1;
}


/* ============================================================
 *  Pool-based matrix operation (add / sub / mul)
 *  op = 1 (add), 2 (sub), 3 (mul)
 * ============================================================ */
MatrixMemory *pool_operation(MatrixMemory *A, MatrixMemory *B, int op, char *op_name) {
    if (!A || !B) {
        printf("pool_operation: NULL matrices\n");
        return NULL;
    }

    int ResultRows = 0;
    int ResultColumns = 0;

    /* --- Dimension checks depend on operation --- */
    if (op == 1 || op == 2) {
        /* ADD / SUB: same size */
        if (A->row != B->row || A->col != B->col) {
            printf("%s: incompatible sizes (%dx%d) and (%dx%d)\n",
                   op_name, A->row, A->col, B->row, B->col);
            return NULL;
        }
        ResultRows    = A->row;
        ResultColumns = A->col;
    } else if (op == 3) {
        /* MUL: A.cols == B.rows */
        if (A->col != B->row) {
            printf("%s: incompatible sizes (%dx%d) * (%dx%d)\n",
                   op_name, A->row, A->col, B->row, B->col);
            return NULL;
        }
        ResultRows    = A->row;
        ResultColumns = B->col;
    } else {
        printf("pool_operation: unknown op = %d\n", op);
        return NULL;
    }

    MatrixMemory *Res = malloc(sizeof(MatrixMemory));
    if (!Res) {
        printf("Error allocation\n");
        return NULL;
    }

    int total = ResultRows * ResultColumns;

    Res->row  = ResultRows;
    Res->col  = ResultColumns;
    Res->kind = MAT_OUTPUT;
    snprintf(Res->name, sizeof(Res->name), "%d(%s)%d", A->ID, op_name, B->ID);

    Res->data = malloc((size_t)ResultRows * (size_t)ResultColumns * sizeof(double));
    if (!Res->data) {
        printf("Error allocation Res->data\n");
        free(Res);
        return NULL;
    }

    int NumOfTasksSent      = 0;
    int NumOfResultsRecieve = 0;

    struct timeval start, end;
    gettimeofday(&start, NULL);

    while (NumOfResultsRecieve < total) {

        while (NumOfTasksSent < total) {
            int w = pool_GetFree();
            if (w < 0)
                break;

            int RowIndex    = NumOfTasksSent / ResultColumns; // row index in result
            int ColumnIndex = NumOfTasksSent % ResultColumns; // col index in result

            Task t;
            memset(&t, 0, sizeof(t));
            t.op = op;
            t.R  = RowIndex;
            t.C  = ColumnIndex;

            if (op == 1 || op == 2) {
                /* -------- ADD / SUB: use scalars elementA / elementB -------- */
                t.elementA = A->data[RowIndex * A->col + ColumnIndex];
                t.elementB = B->data[RowIndex * B->col + ColumnIndex];
            } else if (op == 3) {
                /* -------- MUL: use row[] and col[] -------- */
                t.len = A->col;
                for (int k = 0; k < A->col; ++k) {
                    t.row[k] = A->data[RowIndex * A->col + k];
                    t.col[k] = B->data[k * B->col + ColumnIndex];
                }
            }

            if (pool_SendTask(w, &t) != 0) {
                perror("pool_SendTask");
                free(Res->data);
                free(Res);
                return NULL;
            }

            NumOfTasksSent++;
        }

        Result R;
        int    workerID;
        if (pool_ReadResult(&R, &workerID) != 0) {
            perror("pool_ReadResult");
            break;
        }

        int IDxc = R.R * ResultColumns + R.C;
        Res->data[IDxc] = R.value;

        NumOfResultsRecieve++;
    }

    gettimeofday(&end, NULL);
    double elapsed_ms =
        (end.tv_sec - start.tv_sec) * 1000.0 +
        (end.tv_usec - start.tv_usec) / 1000.0;

    printf("%s operation finished in %.3f ms\n", op_name, elapsed_ms);

    return Res;
}
/* ============================================================
 *  Wrappers for add / sub / multiply
 * ============================================================ */
MatrixMemory *add_matrix(MatrixMemory *A, MatrixMemory *B) {
    return pool_operation(A, B, 1, "Add");
}

MatrixMemory *sub_matrix(MatrixMemory *A, MatrixMemory *B) {
    return pool_operation(A, B, 2, "Sub");
}

MatrixMemory *multiply_matrices(MatrixMemory *A, MatrixMemory *B) {
    return pool_operation(A, B, 3, "Mul");
}

/* ============================================================
 *  Determinant using worker pool (op = 4) + det_gauss_omp
 * ============================================================ */
double det_gauss_omp(const double *data, int n);  // forward
double compute_dominant_eigenvalue(double *raw, int n); // forward

double Determinant(MatrixMemory *M) {
    if (!M) {
        fprintf(stderr, "det_with_pool: NULL matrix pointer\n");
        return 0.0;
    }

    if (M->row != M->col) {
        fprintf(stderr, "det_with_pool: matrix is not square (%dx%d)\n",
                M->row, M->col);
        return 0.0;
    }

    int n = M->row;
    if (n == 0) return 0.0;

    // Small cases local (no pool)
    if (n == 1) {
        return M->data[0];
    }
    if (n == 2) {
        double a = M->data[0 * 2 + 0];
        double b = M->data[0 * 2 + 1];
        double c = M->data[1 * 2 + 0];
        double d = M->data[1 * 2 + 1];
        return a * d - b * c;
    }

    int w = pool_GetFree();
    if (w < 0) {
        fprintf(stderr, "det_with_pool: no free worker, returning 0\n");
        return 0.0;
    }

    Task t;
    memset(&t, 0, sizeof(t));
    t.op  = 4;       // op==4 => determinant
    t.R   = n;
    t.C   = n;
    t.len = n * n;

    // Flatten matrix into t.row[]
    int idx = 0;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            t.row[idx++] = M->data[i * M->col + j];
        }
    }

    if (pool_SendTask(w, &t) != 0) {
        perror("det_with_pool: pool_SendTask");
        return 0.0;
    }

    Result R;
    int workerID;
    if (pool_ReadResult(&R, &workerID) != 0) {
        perror("det_with_pool: pool_ReadResult");
        return 0.0;
    }

    double det = R.value;
    printf("Determinant of matrix (ID=%d, size=%dx%d) = %.6f\n",
           M->ID, n, n, det);

    return det;
}

/* ============================================================
 *  det_gauss_omp: Gaussian elimination with OpenMP timing
 * ============================================================ */
double det_gauss_omp(const double *data, int n) {
    if (n <= 0)
        return 0.0;

    double *A = malloc((size_t)n * n * sizeof(double));
    if (!A) {
        perror("det_gauss_omp: malloc");
        return 0.0;
    }

    for (int i = 0; i < n * n; ++i)
        A[i] = data[i];

    int sign = 1;
    double det = 1.0;

    for (int k = 0; k < n; ++k) {
        int pivot = k;
        double max_val = fabs(A[k * n + k]);

        for (int i = k + 1; i < n; ++i) {
            double val = fabs(A[i * n + k]);
            if (val > max_val) {
                max_val = val;
                pivot = i;
            }
        }

        if (max_val == 0.0) {
            det = 0.0;
            goto cleanup;
        }

        if (pivot != k) {
            for (int j = 0; j < n; ++j) {
                double tmp         = A[k * n + j];
                A[k * n + j]       = A[pivot * n + j];
                A[pivot * n + j]   = tmp;
            }
            sign = -sign;
        }

        double pivot_val = A[k * n + k];

        double start_time = 0.0, end_time = 0.0;

#ifdef _OPENMP
        if (IsOpenMPEnable()) {
            start_time = omp_get_wtime();
            #pragma omp parallel for
            for (int i = k + 1; i < n; ++i) {
                double factor = A[i * n + k] / pivot_val;
                A[i * n + k] = 0.0;
                for (int j = k + 1; j < n; ++j) {
                    A[i * n + j] -= factor * A[k * n + j];
                }
            }
            end_time = omp_get_wtime();
        } else
#endif
        {
            for (int i = k + 1; i < n; ++i) {
                double factor = A[i * n + k] / pivot_val;
                A[i * n + k] = 0.0;
                for (int j = k + 1; j < n; ++j) {
                    A[i * n + j] -= factor * A[k * n + j];
                }
            }
        }

#ifdef _OPENMP
        if (IsOpenMPEnable()) {
            printf("[Worker %d] Determinant elimination step %d done in %.6f seconds\n",
                   getpid(), k, end_time - start_time);
        }
#endif
    }

    for (int i = 0; i < n; ++i)
        det *= A[i * n + i];
    det *= sign;

cleanup:
    free(A);
    return det;
}


/* ============================================================
 *  Power method: dominant eigenvalue (worker-side)
 * ============================================================ */

double compute_dominant_eigenpair(const double *A, int n, double *vec_out)
{
    if (n <= 0)
        return 0.0;

    double *x = malloc((size_t)n * sizeof(double));
    double *y = malloc((size_t)n * sizeof(double));
    if (!x || !y) {
        perror("compute_dominant_eigenpair: malloc x/y");
        free(x);
        free(y);
        return 0.0;
    }
 double start_time = 0.0, end_time = 0.0;
    for (int i = 0; i < n; ++i)
        x[i] = 1.0;

    double lambda   = 0.0;
    int    max_iter = 80;

    for (int it = 0; it < max_iter; ++it) {
       

#ifdef _OPENMP
        if (IsOpenMPEnable()) {
            start_time = omp_get_wtime();
            #pragma omp parallel for
            for (int i = 0; i < n; ++i) {
                double sum = 0.0;
                for (int j = 0; j < n; ++j)
                    sum += A[i * n + j] * x[j];
                y[i] = sum;
            }
            end_time = omp_get_wtime();
                  
        } else
#endif
        {
	  start_time = omp_get_wtime();
            for (int i = 0; i < n; ++i) {
                double sum = 0.0;
                for (int j = 0; j < n; ++j)
                    sum += A[i * n + j] * x[j];
                y[i] = sum;
            }
	    end_time = omp_get_wtime();
        }

        double norm = 0.0;
        for (int i = 0; i < n; ++i)
            norm += y[i] * y[i];
        norm = sqrt(norm);
        if (norm == 0.0)
            break;

        for (int i = 0; i < n; ++i)
            x[i] = y[i] / norm;

        double num = 0.0;
        for (int i = 0; i < n; ++i) {
            double rowdot = 0.0;
            for (int j = 0; j < n; ++j)
                rowdot += A[i * n + j] * x[j];
            num += x[i] * rowdot;
        }
        lambda = num;
    }
   
    printf("[Worker %d] Eigen in %.6f seconds\n",
                   getpid(), end_time - start_time);
     

    // Copy eigenvector out
    for (int i = 0; i < n; ++i)
        vec_out[i] = x[i];

    free(x);
    free(y);
    return lambda;
}

double eigenvalue(MatrixMemory *M)
{
    if (!M || M->row != M->col) {
        fprintf(stderr, "eigenvalue_with_pool: matrix invalid or not square\n");
        return 0.0;
    }

    int n = M->row;
    if (n == 0)
        return 0.0;

    if (n * n > MAX_TASK_DATA) {
        fprintf(stderr,
                "eigenvalue_with_pool: matrix too large (n=%d, n^2=%d > MAX_TASK_DATA=%d)\n",
                n, n * n, MAX_TASK_DATA);
        return 0.0;
    }

    int w = pool_GetFree();
    if (w < 0) {
        fprintf(stderr, "eigenvalue_with_pool: no free worker\n");
        return 0.0;
    }

    Task t;
    memset(&t, 0, sizeof(t));
    t.op  = 5;   // eigen op
    t.R   = n;
    t.C   = n;
    t.len = n * n;

    int idx = 0;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            t.row[idx++] = M->data[i * M->col + j];

    if (pool_SendTask(w, &t) != 0) {
        perror("eigenvalue_with_pool: pool_SendTask");
        return 0.0;
    }

    Result Rres;
    int workerID;
    if (pool_ReadResult(&Rres, &workerID) != 0) {
        perror("eigenvalue_with_pool: pool_ReadResult");
        return 0.0;
    }

    printf("Dominant eigenvalue (approx) = %.6f\n", Rres.value);
    return Rres.value;
}
int eigenpair(MatrixMemory *M, double *lambda_out, double *evec_out)
{
    if (!M || M->row != M->col) {
        fprintf(stderr, "eigenpair_with_pool: matrix invalid or not square\n");
        return -1;
    }
    if (!lambda_out || !evec_out) {
        fprintf(stderr, "eigenpair_with_pool: NULL output pointer\n");
        return -1;
    }

    int n = M->row;
    if (n == 0)
        return -1;

    if (n * n > MAX_TASK_DATA || n > MAX_EIG_VEC) {
        fprintf(stderr,
                "eigenpair_with_pool: matrix too large (n=%d)\n", n);
        return -1;
    }

    int w = pool_GetFree();
    if (w < 0) {
        fprintf(stderr, "eigenpair_with_pool: no free worker\n");
        return -1;
    }

    Task t;
    memset(&t, 0, sizeof(t));
    t.op  = 5;    // same op as eigenvalue (worker returns vec too)
    t.R   = n;
    t.C   = n;
    t.len = n * n;

    int idx = 0;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            t.row[idx++] = M->data[i * M->col + j];

    if (pool_SendTask(w, &t) != 0) {
        perror("eigenpair_with_pool: pool_SendTask");
        return -1;
    }

    Result Rres;
    int workerID;
    if (pool_ReadResult(&Rres, &workerID) != 0) {
        perror("eigenpair_with_pool: pool_ReadResult");
        return -1;
    }

    if (Rres.n != n) {
        fprintf(stderr,
                "eigenpair_with_pool: worker returned vector of size %d (expected %d)\n",
                Rres.n, n);
        return -1;
    }

    *lambda_out = Rres.value;
    for (int i = 0; i < n; ++i)
        evec_out[i] = Rres.vec[i];

    
    return 0;
}
