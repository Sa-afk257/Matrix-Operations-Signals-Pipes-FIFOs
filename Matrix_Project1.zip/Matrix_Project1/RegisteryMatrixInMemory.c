#include <stdio.h>
#include <stdlib.h>
#include "MatrixMemory.h"
#include "RegisteryMatrixInMemory.h"

typedef struct {
    MatrixMemory *matrixItem;   // dynamic array of matrices
    int capacity;               // allocated size
    int NumOfMatrices;          // how many are used
    int NextID;                 // next ID to assign
} RegisterMatrixInMemory;

// Global (internal) registry state
static RegisterMatrixInMemory F = { NULL, 0, 0, 1 };

/*--------------------------------------------------
 * Initialize registry
 *------------------------------------------------*/
void Register_Initial(void)
{
    F.matrixItem    = NULL;
    F.capacity      = 0;
    F.NumOfMatrices = 0;
    F.NextID        = 1;
}

/*--------------------------------------------------
 * Ensure capacity for at least 'capacityNeed' items
 * return 0 on success, -1 on failure
 *------------------------------------------------*/
 int Register_Capacity(int capacityNeed)
{
    if (F.capacity >= capacityNeed)
        return 0;

    int new_capacity = (F.capacity == 0) ? 8 : F.capacity;

    while (new_capacity < capacityNeed)
        new_capacity *= 2;

    MatrixMemory *m = (MatrixMemory *)realloc(
        F.matrixItem,
        (size_t)new_capacity * sizeof(MatrixMemory)
    );
    if (!m) {
        perror("realloc in Register_Capacity");
        return -1;
    }

    F.matrixItem = m;
    F.capacity   = new_capacity;
    return 0;
}

/*--------------------------------------------------
 * Add a matrix to registry
 * - assigns a new ID to *m
 * - returns assigned ID on success
 * - returns -1 on failure
 *------------------------------------------------*/
int Register_Add(MatrixMemory *m)
{
    if (!m)
        return -1;

    if (Register_Capacity(F.NumOfMatrices + 1) != 0)
        return -1;

    // Important: MatrixMemory must have an 'ID' field
    m->ID = F.NextID++;

    F.matrixItem[F.NumOfMatrices] = *m;  // copy struct
    F.NumOfMatrices++;

    return m->ID;
}

/*--------------------------------------------------
 * Find matrix by ID
 * return pointer to MatrixMemory or NULL
 *------------------------------------------------*/
MatrixMemory *Register_Find(int MatrixID)
{
    for (int i = 0; i < F.NumOfMatrices; i++) {
        if (F.matrixItem[i].ID == MatrixID)
            return &F.matrixItem[i];
    }
    return NULL;
}

/*--------------------------------------------------
 * Delete matrix by ID
 * - swap with last item and shrink count
 * - return 0 on success, -1 if not found
 *------------------------------------------------*/
int Register_Delete(int MatrixID)
{
    for (int i = 0; i < F.NumOfMatrices; i++) {
        if (F.matrixItem[i].ID == MatrixID) {
            F.matrixItem[i] = F.matrixItem[F.NumOfMatrices - 1];
            F.NumOfMatrices--;
            return 0;
        }
    }
    return -1;
}

/*--------------------------------------------------
 * Free all matrices and reset registry
 *------------------------------------------------*/
void Register_FreeAll(void)
{
    free(F.matrixItem);
    F.matrixItem    = NULL;
    F.capacity      = 0;
    F.NumOfMatrices = 0;
    F.NextID        = 1;
}

/*--------------------------------------------------
 * Print list of matrices in memory
 * (you can customize the fields to print)
 *------------------------------------------------*/
void Register_ListOfMatrices(void)
{
    if (F.NumOfMatrices == 0) {
        printf("No matrices in memory.\n");
        return;
    }

    printf("=== Matrices in memory ===\n");
    printf("ID\tRows\tCols\n");
    for (int i = 0; i < F.NumOfMatrices; i++) {
        printf("%d\t%d\t%d\n",
               F.matrixItem[i].ID,
               F.matrixItem[i].row,
               F.matrixItem[i].col);
    }
}

/*--------------------------------------------------
 * Return number of matrices in registry
 *------------------------------------------------*/
int Register_count(void)
{
    return F.NumOfMatrices;
}
