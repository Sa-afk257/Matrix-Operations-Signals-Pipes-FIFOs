#ifndef __MENU_H_
#define __MENU_H_


//for menu list
typedef struct {
  int id;
  char description[128];
}MenuItem ;

// for reordered menu
typedef struct {
  int menu_order[20];
  int menu_count;
}MenuOrder ;

extern const char *configPath;

void PrintMenu(MenuOrder *fm);
void HandelChoice(int choice ,MenuOrder *fm );
void LoadMenuOrderFromConfig(MenuOrder *fm);

void OpenConfigForEditAndReload(MenuOrder *fm);


void EnableOpenMP();
void DisableOpenMP();
int IsOpenMPEnable();


void menu_add_matrix(void);
void menu_sub_matrix(void);
void menu_multiply_matrices(void);
void menu_determinant(void);
void menu_eigenvalue(void);

#endif
