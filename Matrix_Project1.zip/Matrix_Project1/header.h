#ifndef __HEADER_H_
#define __HEADER_H_

#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/select.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <limits.h>
#include <stdlib.h>
#include <ctype.h>
#include <omp.h>
#include <time.h>
#include <signal.h>
#include <dirent.h>
#include <math.h>




#endif


