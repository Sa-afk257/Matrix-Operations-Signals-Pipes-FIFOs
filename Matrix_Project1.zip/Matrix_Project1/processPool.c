
#ifdef _OPENMP
#include <omp.h>
#endif

#include "processPool.h"
#include "menu.h"
#include "header.h"
#include "MatrixMemory.h"
#include "RegisteryMatrixInMemory.h"
#include "FileIO.h"
#include "operation.h"


worker *pool = NULL;
int     NumOfWorkers = 0;

/* ============================================================
 * Read number of worker processes from config.txt
 * ============================================================ */
int ReadWorkerProcessFromConfig(void)
{
    int NumOfWorkerOnDevice = (int)sysconf(_SC_NPROCESSORS_ONLN);
    if (NumOfWorkerOnDevice <= 0)
        NumOfWorkerOnDevice = 2;
    if (NumOfWorkerOnDevice > 8)
        NumOfWorkerOnDevice = 8;

    FILE *f = fopen(configPath, "r");
    if (!f)
        return NumOfWorkerOnDevice;

    int  value;

     char line[2048];
    while (fgets(line, sizeof line, f)) {
        line[strcspn(line, "\r\n")] = '\0'; // strip newline

        char *s = line;
        while (*s == ' ' || *s == '\t')
            s++;
        if (strncmp(s, "Process_Worker", 14) != 0)
            continue;
	
    char *eq = strchr(s, '=');
        if (!eq)
            continue;
        eq++;
        while (*eq == ' ' || *eq == '\t')
            eq++;

	 value = atoi(eq);
        if (value > 0) {
            if (value > 8)      // keep your upper cap if you want
                value = 8;
            NumOfWorkerOnDevice = value;
        }

        // we found the key, no need to continue scanning
        break;
    }

    fclose(f);
    return NumOfWorkerOnDevice;
}

/* ============================================================
 * Initialize pool (called from main once)
 * ============================================================ */
int Pool_Initial(void)
{
    if (pool != NULL)
        return -1;

    int ProcessWorkers = ReadWorkerProcessFromConfig();
    printf("The pool starting with %d workers\n", ProcessWorkers);

    if (Pool_start(ProcessWorkers) != 0) {
        fprintf(stderr, "Failed to start pool\n");
        return -1;
    }
    return 0;
}

/* ============================================================
 * Actually create N workers and fill pool[]
 * ============================================================ */
int Pool_start(int ProcessWorkers)
{
    if (ProcessWorkers <= 0) {
        printf("The number of workers must be > 0\n");
        return -1;
    }

    pool = (worker *)calloc((size_t)ProcessWorkers, sizeof(worker));
    if (!pool) {
        perror("calloc pool");
        return -1;
    }

    NumOfWorkers = ProcessWorkers;

    for (int i = 0; i < NumOfWorkers; i++) {
        if (Create_Worker(&pool[i]) != 0) {
            perror("Create_Worker");
            for (int j = 0; j < i; j++)
                stop_worker(&pool[j]);
            free(pool);
            pool = NULL;
            NumOfWorkers = 0;
            return -1;
        }
    }
    return 0;
}

/* ============================================================
 * Create one worker process with two pipes
 * ============================================================ */
int Create_Worker(worker *w)
{
    int parent_child[2];  // parent writes to child
    int child_parent[2];  // child writes to parent

    if (pipe(parent_child) == -1)
        return -1;

    if (pipe(child_parent) == -1) {
        close(parent_child[0]);
        close(parent_child[1]);
        return -1;
    }

    pid_t pid = fork();
    if (pid < 0) {
        close(parent_child[0]);
        close(parent_child[1]);
        close(child_parent[0]);
        close(child_parent[1]);
        return -1;
    }

    if (pid == 0) {
        /* ---------------- Child process ---------------- */
        close(parent_child[1]);   // close parent's write end
        close(child_parent[0]);   // close parent's read end

        // child: read tasks, write results
        working(parent_child[0], child_parent[1]);

        _exit(0);
    }

    /* ---------------- Parent process ---------------- */
    close(parent_child[0]);   // parent doesn’t read from this pipe
    close(child_parent[1]);   // parent doesn’t write to this pipe

    w->PID        = pid;
    w->to_child   = parent_child[1];
    w->from_child = child_parent[0];
    w->busy       = 0;

    return 0;
}

/* ============================================================
 * Worker main loop
 *  - read Task from pipe
 *  - compute
 *  - write Result back
 * ============================================================ */
void working(int read_fd, int write_fd)
{
    for (;;) {
        Task task;
        ssize_t n = read(read_fd, &task, sizeof(task));
        if (n == 0) {
            // parent closed pipe
            _exit(0);
        }
        if (n < 0) {
            perror("worker read");
            _exit(1);
        }

        // Stop command
        if (task.op == -1)
            _exit(0);

        Result result;
        memset(&result, 0, sizeof(result));
        result.IDtask = task.IDtask;
        result.R      = task.R;
        result.C      = task.C;
        result.value  = 0.0;

        /* ---------------- Operations ---------------- */

	int N;
	double sum , start ,end ,det;
	
        if (task.op == 1) {
            // Add
            result.value = task.elementA + task.elementB;
        }
        else if (task.op == 2) {
            // Sub
            result.value = task.elementA - task.elementB;
        }
        else if (task.op == 3) {
            // Dot product of row[] and col[]
             sum = 0.0;

#ifdef _OPENMP
            if (IsOpenMPEnable()) {
                 start = omp_get_wtime();
#pragma omp parallel for reduction(+:sum)
                for (int i = 0; i < task.len; i++) {
                    sum += task.row[i] * task.col[i];
                }
                 end = omp_get_wtime();
                printf("[Worker %d] OpenMP dot time = %.6f sec (len=%d)\n",
                       getpid(), end - start, task.len);
            } else
#endif
            {
#ifdef _OPENMP
                 start = omp_get_wtime();
#endif
                for (int i = 0; i < task.len; i++) {
                    sum += task.row[i] * task.col[i];
                }
#ifdef _OPENMP
                 end = omp_get_wtime();
                printf("[Worker %d] Serial dot time = %.6f sec (len=%d)\n",
                       getpid(), end - start, task.len);
#endif
            }

            result.value = sum;
        }
        else if (task.op == 4) {
            // Determinant: task.R = n, task.row contains n*n matrix
             N = task.R;
             det = det_gauss_omp(task.row, N);
            result.value = det;
        }
        else if (task.op == 5) {
            // dominant eigenvalue + eigenvector
            int n_dim = task.R;
            if (n_dim > MAX_EIG_VEC) {
                fprintf(stderr,
                        "[Worker %d] eigen n=%d exceeds MAX_EIG_VEC=%d\n",
                        getpid(), n_dim, MAX_EIG_VEC);
                result.value = 0.0;
                result.n     = 0;
            } else {
                double vec[MAX_EIG_VEC];
                double lambda = compute_dominant_eigenpair(task.row, n_dim, vec);
                result.value = lambda;
                result.n     = n_dim;
                for (int i = 0; i < n_dim; ++i)
                    result.vec[i] = vec[i];
            }
        }
        else {
            // Unknown operation
            fprintf(stderr, "[Worker %d] Unknown op %d\n", getpid(), task.op);
        }

        /* ---------------- Send result back ---------------- */
        if (write(write_fd, &result, sizeof(result)) != (ssize_t)sizeof(result)) {
            perror("worker write");
            _exit(1);
        }
    }
}

/* ============================================================
 * Stop one worker
 * ============================================================ */
void stop_worker(worker *w)
{
    if (!w || w->PID <= 0)
        return;

    Task stop_task;
    memset(&stop_task, 0, sizeof(stop_task));
    stop_task.op = -1;

    (void)write(w->to_child, &stop_task, sizeof(stop_task));

    close(w->to_child);
    close(w->from_child);

    waitpid(w->PID, NULL, 0);
    w->PID = -1;
}

/* ============================================================
 * Send one task to a specific worker
 * ============================================================ */
int pool_SendTask(int workerID, Task *task)
{
    if (!pool || !task || workerID < 0 || workerID >= NumOfWorkers)
        return -1;

    worker *w = &pool[workerID];

    ssize_t n = write(w->to_child, task, sizeof(*task));
    if (n != (ssize_t)sizeof(*task))
        return -1;

    w->busy = 1;
    return 0;
}

/* ============================================================
 * Read a result from any worker (blocking)
 * ============================================================ */
int pool_ReadResult(Result *result, int *which_worker)
{
    if (!pool || !result)
        return -1;

    fd_set rfds;
    FD_ZERO(&rfds);
    int maxfd = -1;

    for (int i = 0; i < NumOfWorkers; i++) {
        int fd = pool[i].from_child;
        FD_SET(fd, &rfds);
        if (fd > maxfd)
            maxfd = fd;
    }

    int rc = select(maxfd + 1, &rfds, NULL, NULL, NULL);
    if (rc <= 0)
        return -1;

    for (int i = 0; i < NumOfWorkers; i++) {
        int fd = pool[i].from_child;
        if (FD_ISSET(fd, &rfds)) {
            ssize_t n = read(fd, result, sizeof(*result));
            if (n != (ssize_t)sizeof(*result))
                return -1;

            pool[i].busy = 0;
            if (which_worker)
                *which_worker = i;

            return 0;
        }
    }

    return -1;
}

/* ============================================================
 * Get index of a free worker, or -1 if none
 * ============================================================ */
int pool_GetFree(void)
{
    if (!pool)
        return -1;

    for (int i = 0; i < NumOfWorkers; i++) {
        if (!pool[i].busy && pool[i].PID > 0)
            return i;
    }
    return -1;
}

/* ============================================================
 * Shutdown pool (called at program exit)
 * ============================================================ */
void Pool_Shutdown(void)
{
    if (!pool || NumOfWorkers <= 0)
        return;

    for (int i = 0; i < NumOfWorkers; i++)
        stop_worker(&pool[i]);

    free(pool);
    pool = NULL;
    NumOfWorkers = 0;
}


int Pool_ReconfigureFromConfig(void)
{
    int newWorkers = ReadWorkerProcessFromConfig();
    if (newWorkers <= 0) {
        fprintf(stderr, "Pool_ReconfigureFromConfig: invalid worker count %d\n", newWorkers);
        return -1;
    }

    /* If pool already exists and same size, do nothing */
    if (pool && NumOfWorkers == newWorkers) {
        printf("Process_Worker unchanged (%d), pool not restarted.\n", newWorkers);
        return 0;
    }

    /* Stop old pool (if any) */
    Pool_Shutdown();

    /* Start new pool */
    if (Pool_start(newWorkers) != 0) {
        fprintf(stderr, "Pool_ReconfigureFromConfig: failed to start pool with %d workers\n",
                newWorkers);
        return -1;
    }

    printf("Process pool restarted with %d worker(s).\n", newWorkers);
    return 0;
}
