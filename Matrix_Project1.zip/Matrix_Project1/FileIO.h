#ifndef FileIO_H
#define FileIO_H

#include "MatrixMemory.h"

int  ReadMatriexFromUser (MatrixMemory *matrix);
void ReadMatrixDirection(void);
int ReadMatrixFromFile(int index );
int ReadFromFolder(int index);
double CurrentTime(void);

int SaveMatrixToFile(void);
int SaveAllMatricesToFolder(void);

void DisplayMatrix(void);
void DisplayAllMatrices(void);

#endif
