#include "menu.h"
#include "header.h"
#include "MatrixMemory.h"
#include "RegisteryMatrixInMemory.h"
#include "FileIO.h"
#include "operation.h"
#include "processPool.h"


//Run the matrix project: gcc -std=c11 -Wall -Wextra -O2 -fopenmp *.c -o matrix_app

static MenuItem MenuList[] = {
    {1 , "Enter a matrix"},
    {2 , "Display a matrix"},
    {3 , "Delete a matrix"},
    {4 , "Modify a matrix"},
    {5 , "Read a matrix from a file"},
    {6 , "Read a set of matrices from a folder"},
    {7 , "Save a matrix to a file"},
    {8 , "Save all matrices in memory to a folder"},
    {9 , "Display all matrices in memory"},
    {10, "Add 2 matrices"},
    {11, "Subtract 2 matrices"},
    {12, "Multiply 2 matrices"},
    {13, "Find the determinant of a matrix"},
    {14, "Find eigenvalues & eigenvectors of a matrix"},
    {15, "Configration"},
    {16, "Enable openMP"},
    {17, "Desable openMP"},
    {18, "Exit"}
};

static const int MenuSize = (int)(sizeof(MenuList) / sizeof(MenuList[0]));
const char *configPath = "config.txt";


// --------------------Load Menu Order-------------------
void LoadMenuOrderFromConfig(MenuOrder *fm){

  fm -> menu_count = 0;
  
  FILE *f = fopen(configPath, "r");
  if (!f) {      // file not found
    printf("config.txt not found.Using default order.\n");
    for (int i = 0; i < MenuSize ; i++)
	   fm->menu_order[i] = i+1;
    fm -> menu_count = MenuSize ;
    return ;
	 }

  
  char line [2048];
  while (fgets(line, sizeof line, f)){

    // strip newline
    line[strcspn(line, "\r\n")] = '\0';

    //find menu order
    char *s = line;
    while(*s == ' '|| *s == '\t')
	s++;
    if (strncmp(s, "menu_order",10) != 0)
      continue;
    
    //find '='
      char *eq = strchr(s, '=');
      if (!eq)
	continue;
      eq++;
      while(*eq == ' '|| *eq == '\t')
	eq++;
      // tokenize numbers by comma
      char *tok = strtok(eq, ", \t");
      while(tok && fm->menu_count < MenuSize){
	fm->menu_order[fm->menu_count] = atoi(tok);
	fm->menu_count++;
	tok = strtok(NULL, ", \t");
      }
      break;
    }
  
  fclose(f);
  //if empty menu array
  if (fm->menu_count == 0){
    for (int i = 0; i < MenuSize ; i++)
      fm->menu_order[i] = i+1;
    fm -> menu_count = MenuSize ;
  }
  return;
}

void PrintMenu(MenuOrder *fm) {
     
    printf("------------------------------ Matrix Menu ------------------------------\n");
    
    for (int i = 0; i < fm->menu_count; i++){
      int id = fm->menu_order[i];
      if(id >= 1 && id <= MenuSize)
        printf("%d) %s\n", i+1, MenuList[id-1].description);
    }
    printf("-------------------------------------------------------------------------\n");
}
//----------------------------------------------------------------------

//----------------------------------------OpenMP Flag Setting------------------------------
static int OpenMPFlag = 0;

void EnableOpenMP(){
  OpenMPFlag = 1;
  printf("OpenMP: ENABLED");
}

void DisableOpenMP(){
  OpenMPFlag = 0;
  printf("OpenMP: DISABLED");
}
int IsOpenMPEnable(){
  return OpenMPFlag;
}

//-------------------------------------------------------------------------------------
void HandelChoice(int choice ,MenuOrder *fm ){
  
  switch (fm->menu_order[choice-1]) {
  case 1:{
    MatrixMemory matrix;
    int id = ReadMatriexFromUser (&matrix);
    if(id < 0)
      printf("Failed to read matrix from user.\n");
    break;
  }
  case 2:
    DisplayMatrix();
    break;
  case 3:
    Delete_Matrix();
    break;
  case 4:
    Modify_Matrix();
    break;
  case 5:
    ReadMatrixDirection();
    break;
  case 6:
    ReadMatrixDirection();
    break;
  case 7:
    SaveMatrixToFile();
    break;
  case 8:
    SaveAllMatricesToFolder();
    break;
  case 9:
    DisplayAllMatrices();
    break;
  case 10:
    menu_add_matrix();
    break;
  case 11:
    menu_sub_matrix();
    break;
  case 12:
    menu_multiply_matrices();
    break;
  case 13:
    menu_determinant();
    break;
  case 14:
    menu_eigenvalue();
    break;
  case 15:
    printf("Configration choosen\n");
    OpenConfigForEditAndReload(fm);
    break;
  case 16:
    EnableOpenMP();
    break;
  case 17:
    DisableOpenMP();
    break;
  default: printf("Invalid choice: %d\n",choice);
    break;
  }
}
int main(){

   MenuOrder fm;
   int choice = 0, ch;

   if(Pool_Initial() != 0){
     printf("Error: Faild create worker pool\n");
     return -1;
   }

    printf("=========================================\n");
    printf("     Matrix Operations Project (ENCS4330)\n");
    printf("=========================================\n");

    
   while(1){
     LoadMenuOrderFromConfig(&fm);
     PrintMenu(&fm);
    
    printf("Enter your choice:");
    if(scanf("%d",&choice) != 1)
      {
	printf("Input error.\n");
        return 1;
      }
    while((ch = getchar()) != '\n' && ch != EOF){}

     printf("Choice:%d\n",choice);
     if(fm.menu_order[choice-1] == 18)
       break;
     
     HandelChoice(choice,&fm);
    } 
  
    printf("\n=========================================\n");
    printf("Cleaning up before exit...\n");

    // shut down the worker pool
    printf("Shutting down worker pool...\n");
    Pool_Shutdown();          // unified cleanup: stop workers, close pipes, free arrays
    printf("All worker processes stopped.\n");

    // Free all matrices from memory
    printf("Releasing matrix memory...\n");
    Register_FreeAll();
    printf("All matrices released.\n");

    // OpenMP disable
    DisableOpenMP();

    printf("Cleanup completed successfully.\n");
    printf("Program exited cleanly.\n");
    printf("=========================================\n");
 
  return 0;
}
//-------------------------operations----------------------------

static int get_two_matrices(MatrixMemory **A, MatrixMemory **B) {
    int idA, idB, ch;

    Register_ListOfMatrices();
    printf("Enter ID of first matrix: ");
    if (scanf("%d", &idA) != 1) {
        printf("Input error.\n");
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return -1;
    }
    while ((ch = getchar()) != '\n' && ch != EOF) {}

    printf("Enter ID of second matrix: ");
    if (scanf("%d", &idB) != 1) {
        printf("Input error.\n");
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return -1;
    }
    while ((ch = getchar()) != '\n' && ch != EOF) {}

    *A = Register_Find(idA);
    *B = Register_Find(idB);

    if (!*A || !*B) {
        printf("One or both matrices not found.\n");
        return -1;
    }
    return 0;
}

// 1) A + B
void menu_add_matrix(void) {
    MatrixMemory *A = NULL, *B = NULL;
    if (get_two_matrices(&A, &B) != 0)
        return;

    MatrixMemory *C = add_matrix(A, B);
    if (!C) {
        printf("Addition failed.\n");
        return;
    }

    int ID = Register_Add(C);
    if (ID < 0) {
        printf("Failed to register result matrix.\n");
        free(C->data);
        free(C);
        return;
    }

    printf("Result of A + B stored as ID=%d, name=%s\n", C->ID, C->name);
    DisplayMatrix();   // optional: you can instead print C directly
}

// 2) A - B
void menu_sub_matrix(void) {
    MatrixMemory *A = NULL, *B = NULL;
    if (get_two_matrices(&A, &B) != 0)
        return;

    MatrixMemory *C = sub_matrix(A, B);
    if (!C) {
        printf("Subtraction failed.\n");
        return;
    }

    int ID = Register_Add(C);
    if (ID < 0) {
        printf("Failed to register result matrix.\n");
        free(C->data);
        free(C);
        return;
    }

    printf("Result of A - B stored as ID=%d, name=%s\n", C->ID, C->name);
    DisplayMatrix();
}

// 3) A * B
void menu_multiply_matrices(void) {
    MatrixMemory *A = NULL, *B = NULL;
    if (get_two_matrices(&A, &B) != 0)
        return;

    MatrixMemory *C = multiply_matrices(A, B);
    if (!C) {
        printf("Multiplication failed.\n");
        return;
    }

    int ID = Register_Add(C);
    if (ID < 0) {
        printf("Failed to register result matrix.\n");
        free(C->data);
        free(C);
        return;
    }

    printf("Result of A * B stored as ID=%d, name=%s\n", C->ID, C->name);
    DisplayMatrix();
}

// 4) det(M)
void menu_determinant(void) {
    int ID, ch;
    if (Register_count() == 0) {
        printf("No matrices in memory.\n");
        return;
    }

    Register_ListOfMatrices();
    printf("Enter matrix ID for determinant: ");
    if (scanf("%d", &ID) != 1) {
        printf("Input error.\n");
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return;
    }
    while ((ch = getchar()) != '\n' && ch != EOF) {}

    MatrixMemory *M = Register_Find(ID);
    if (!M) {
        printf("Matrix not found.\n");
        return;
    }

    double det = Determinant(M);
    printf("Determinant = %.6f\n", det);
}

// 5) eigenvalue(M)
void menu_eigenvalue(void)
{
  int id,ch;
    printf("Enter matrix ID: ");
    if (scanf("%d", &id) != 1) {
        printf("Input error.\n");
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return;
    }
    while ((ch = getchar()) != '\n' && ch != EOF) {}


    MatrixMemory *M = Register_Find(id);
    if (!M) {
        printf("Matrix with ID %d not found!\n", id);
        return;
    }

    if (M->row != M->col) {
        printf("Matrix must be square to compute eigenvalues/vectors!\n");
        return;
    }

    int n = M->row;
    double lambda;
    double *vec = malloc((size_t)n * sizeof(double));
    if (!vec) {
        printf("Memory allocation failed!\n");
        return;
    }

    printf("\nComputing dominant eigenvalue and eigenvector...\n");

    if (eigenpair(M, &lambda, vec) == 0) {
        printf("\nDominant Eigenvalue: %.6f\n", lambda);
        printf("Corresponding Eigenvector:\n");
        for (int i = 0; i < n; ++i)
            printf("   v[%d] = %.6f\n", i, vec[i]);
    } else {
        printf("Failed to compute eigenvalue/eigenvector.\n");
    }

    free(vec);
}
