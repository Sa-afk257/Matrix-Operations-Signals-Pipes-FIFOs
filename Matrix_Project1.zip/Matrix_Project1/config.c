#include "menu.h"
#include "header.h"
#include "processPool.h"

void OpenConfigForEditAndReload(MenuOrder *fm)
{
  
    int fd = open(configPath, O_CREAT | O_RDWR, 0666);
    if (fd >= 0)
        close(fd);

    chmod(configPath, 0666);

    const char *editor = getenv("EDITOR");
    if (!editor || !*editor)
        editor = "nano";

    char cmd[4096];
    int written = snprintf(cmd, sizeof(cmd), "%s \"%s\"", editor, configPath);
    if (written < 0 || written >= (int)sizeof(cmd)) {
        fprintf(stderr, "ERROR: editor command too long in OpenConfigForEditAndReload\n");
        return;
    }

    int ret = system(cmd);
    if (ret == -1) {
        perror("system");
        return;  
    }
    
    LoadMenuOrderFromConfig(fm);
    printf("Configuration reloaded from config.txt\n");

    if (Pool_ReconfigureFromConfig() == 0) {
        printf("Process pool reconfigured according to updated Process_Worker.\n");
    } else {
        fprintf(stderr, "Warning: failed to reconfigure process pool after config change.\n");
    }
}

