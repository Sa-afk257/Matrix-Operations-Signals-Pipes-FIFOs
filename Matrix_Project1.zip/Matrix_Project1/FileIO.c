
#ifdef _OPENMP
#include <omp.h>
#endif

#include "menu.h"
#include "header.h"
#include "MatrixMemory.h"
#include "RegisteryMatrixInMemory.h"
#include "FileIO.h"
#include "operation.h"
#include "processPool.h"

extern const char *configPath;   // declared in menu.h

static const char *DefaultDir = "/home/sara-al-souqi/Matrix_Project1/";

#define MAXDIR 16
static char MatrixDir[MAXDIR][PATH_MAX];
static int  MatrixDirCount;

/* Forward for path-based reader */
static int ReadMatrixFromFilePath(const char *path);

/* ============================================================
 * Read matrix from user
 * ============================================================ */
int ReadMatriexFromUser(MatrixMemory *matrix) {
    if (!matrix) {
        printf("ReadMatriexFromUser: NULL pointer\n");
        return -1;
    }

    int row = 0, col = 0;
    int ch;

    printf("Enter number of Rows:\n");
    if (scanf("%d", &row) != 1 || row <= 0) {
        printf("Invalid Rows\n");
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return -1;
    }

    printf("Enter number of Columns:\n");
    if (scanf("%d", &col) != 1 || col <= 0) {
        printf("Invalid Columns\n");
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return -1;
    }

    while ((ch = getchar()) != '\n' && ch != EOF) {}   // flush

    size_t n = (size_t)row * (size_t)col;
    double *data = malloc(n * sizeof(double));
    if (!data) {
        printf("Failed to allocate 'data'\n");
        return -1;
    }

    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            int idx = i * col + j;
            printf("Enter the value of row(%d), col(%d): ", i, j);
            if (scanf("%lf", &data[idx]) != 1) {   // %lf for double
                printf("Invalid number\n");
                free(data);
                while ((ch = getchar()) != '\n' && ch != EOF) {}
                return -1;
            }
        }
    }
    while ((ch = getchar()) != '\n' && ch != EOF) {}

    matrix->row  = row;
    matrix->col  = col;
    matrix->data = data;
    matrix->kind = MAT_INPUT;
    snprintf(matrix->name, sizeof(matrix->name), "M%d", Register_count() + 1);

    int ID = Register_Add(matrix);
    if (ID < 0) {
        printf("Failed to register matrix\n");
        free(data);
        return -1;
    }

    printf("Created matrix[%dx%d] with ID = %d and name: %s\n",
           row, col, ID, matrix->name);

    return ID;
}

/* ============================================================
 * Read matrix directories from config.txt and load them
 * ============================================================ */
void ReadMatrixDirection(void) {
    MatrixDirCount = 0;

    FILE *f = fopen(configPath, "r");
    if (!f) {
        printf("config.txt not found. Using default directory.\n");
        snprintf(MatrixDir[MatrixDirCount++], PATH_MAX, "%s", DefaultDir);
        return;
    }

    char line[2048];
    while (fgets(line, sizeof line, f)) {
        line[strcspn(line, "\r\n")] = '\0'; // strip newline

        char *s = line;
        while (*s == ' ' || *s == '\t')
            s++;
        if (strncmp(s, "mat_dir", 7) != 0)
            continue;

        char *eq = strchr(s, '=');
        if (!eq)
            continue;
        eq++;
        while (*eq == ' ' || *eq == '\t')
            eq++;

        if (MatrixDirCount < MAXDIR) {
            snprintf(MatrixDir[MatrixDirCount], PATH_MAX, "%s", eq);
            MatrixDirCount++;
        }
    }

    fclose(f);

    if (MatrixDirCount == 0) {
        printf("No directory found in config.txt. Using default.\n");
        snprintf(MatrixDir[MatrixDirCount++], PATH_MAX, "%s", DefaultDir);
    }

    printf("Loaded %d directory path(s):\n", MatrixDirCount);
    for (int i = 0; i < MatrixDirCount; i++) {
        printf("  %d) %s\n", i + 1, MatrixDir[i]);
    }

    /* For each path, detect if file/dir, then load */
    for (int i = 0; i < MatrixDirCount; i++) {
        struct stat st;
        if (stat(MatrixDir[i], &st) != 0) {
            printf("Path not found: %s\n", MatrixDir[i]);
            continue;
        }

        if (S_ISDIR(st.st_mode)) {
            printf("%s => is a Directory.\n", MatrixDir[i]);
            ReadFromFolder(i);
        } else if (S_ISREG(st.st_mode)) {
            printf("%s => is a File.\n", MatrixDir[i]);
            ReadMatrixFromFile(i);
        } else {
            printf("%s => is neither a File nor a Directory.\n", MatrixDir[i]);
        }
    }
}

/* ============================================================
 * Current time in milliseconds
 * ============================================================ */
double CurrentTime(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1e6;
}

/* ============================================================
 * Read matrix from file by index into MatrixDir[]
 * ============================================================ */
int ReadMatrixFromFile(int index) {
    if (index < 0 || index >= MatrixDirCount)
        return -1;
    return ReadMatrixFromFilePath(MatrixDir[index]);
}

/* ============================================================
 * Read matrix from a given path (internal helper)
 * ============================================================ */
static int ReadMatrixFromFilePath(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f)
        return -1;

    char   line[8192];
    int    row = 0, col = -1;
    double *buffer = NULL;
    size_t len = 0, capacity = 0;

    while (fgets(line, sizeof(line), f)) {
        size_t L = strlen(line);
        while (L && (line[L - 1] == '\n' || line[L - 1] == '\r'))
            line[--L] = '\0';

        char *p = line;
        while (*p && isspace((unsigned char)*p))
            p++;

        if (*p == '\0') {
            /* blank line */
            continue;
        }

        int RowCount = 0;
        char *endp = NULL;

        for (char *tok = strtok(p, " \t"); tok; tok = strtok(NULL, " \t")) {
            double value = strtod(tok, &endp);
            if (endp == tok) {
                printf("Error in row %d => (value: %s) in path: %s\n",
                       row + 1, tok, path);
                free(buffer);
                fclose(f);
                return -1;
            }

            if (len == capacity) {
                size_t newCapacity = capacity ? capacity * 2 : 64;
                double *tmp = realloc(buffer, newCapacity * sizeof(double));
                if (!tmp) {
                    printf("Out of memory\n");
                    free(buffer);
                    fclose(f);
                    return -1;
                }
                buffer   = tmp;
                capacity = newCapacity;
            }

            buffer[len++] = value;
            RowCount++;
        }

        if (RowCount == 0)
            continue;

        if (col < 0)
            col = RowCount;
        else if (RowCount != col) {
            printf("Row %d has %d values; expected %d. from path => %s\n",
                   row + 1, RowCount, col, path);
            free(buffer);
            fclose(f);
            return -1;
        }

        row++;
    }

    fclose(f);

    if (row == 0 || col <= 0) {
        printf("No data in %s\n", path);
        free(buffer);
        return -1;
    }

    MatrixMemory m;
    memset(&m, 0, sizeof(m));
    m.row  = row;
    m.col  = col;
    m.data = buffer;
    m.kind = MAT_INPUT;

    const char *base = strrchr(path, '/');
    if (base)
        base++;
    else
        base = path;

    snprintf(m.name, sizeof(m.name), "%s", base);

#ifdef _OPENMP
#pragma omp critical(Register)
#endif
    {
        int ID = Register_Add(&m);
        if (ID < 0) {
            printf("Failed to register matrix\n");
            free(buffer);
            row = -1;
        }
	else
	  printf("Loaded matrix %s[%dx%d] with ID = %d\n", m.name, row, col, ID);
    }
    if(row < 0){
      free(buffer);
      return -1;
    }

    return 0;
}

/* ============================================================
 * Read all matrices from a folder index
 * ============================================================ */
int ReadFromFolder(int index) {
    enum { MAX_FILES = 1024 };
    char Files[MAX_FILES][PATH_MAX];
    int  count = 0;

    if (index < 0 || index >= MatrixDirCount)
        return -1;

    DIR *dirp = opendir(MatrixDir[index]);
    if (!dirp) {
        printf("Cannot open directory: %s\n", MatrixDir[index]);
        return -1;
    }

    struct dirent *ent;
    while ((ent = readdir(dirp)) != NULL) {
        const char *name = ent->d_name;
        if (name[0] == '.')
            continue;

        size_t L = strlen(name);
        if (L < 4 || strcmp(name + (L - 4), ".txt") != 0)
            continue;

        if (count >= MAX_FILES)
            break;

        snprintf(Files[count], PATH_MAX, "%s/%s", MatrixDir[index], name);
        count++;
    }
    closedir(dirp);

    if (count == 0) {
        printf("No .txt file in: %s\n", MatrixDir[index]);
        return 0;
    }

    printf("Found %d file(s) in %s\n", count, MatrixDir[index]);

    double t0 = CurrentTime();
    int ok = 0, fail = 0;

    if (IsOpenMPEnable()) {
#ifdef _OPENMP
#pragma omp parallel for schedule(dynamic) reduction(+:ok,fail)
        for (int i = 0; i < count; i++) {
            int id = ReadMatrixFromFilePath(Files[i]);
            if (id >= 0)
                ok++;
            else
                fail++;
        }
#else
        printf("OpenMP is not defined; Running in serial\n");
        for (int i = 0; i < count; i++) {
            int id = ReadMatrixFromFilePath(Files[i]);
            if (id >= 0)
                ok++;
            else
                fail++;
        }
#endif
    } else {
        for (int i = 0; i < count; i++) {
            int id = ReadMatrixFromFilePath(Files[i]);
            if (id >= 0)
                ok++;
            else
                fail++;
        }
    }

    double t1 = CurrentTime();
    printf("Imported %d/%d file(s) from %s in %.2f ms (failed: %d)\n",
           ok, count, MatrixDir[index], t1 - t0, fail);

    return ok;
}

/* ============================================================
 * Save a single matrix to file
 * ============================================================ */
int SaveMatrixToFile(void) {
    int TotalNum = Register_count();
    if (TotalNum == 0) {
        printf("The memory is Empty\n");
        return -1;
    }

    Register_ListOfMatrices();

    int ID, ch;
    printf("Enter Matrix ID to save: ");
    if (scanf("%d", &ID) != 1) {
        printf("Input Error\n");
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return -1;
    }
    while ((ch = getchar()) != '\n' && ch != EOF) {}

    MatrixMemory *m = Register_Find(ID);
    if (!m) {
        printf("Matrix not found\n");
        return -1;
    }

    char path[PATH_MAX];
    char fullpath[PATH_MAX];
    printf("Enter the file path where will save the matrix (empty = default): ");
    if (!fgets(path, sizeof path, stdin)) {
        printf("Input Error\n");
        return -1;
    }
    path[strcspn(path, "\r\n")] = '\0';

    if (path[0] == '\0') {
        snprintf(fullpath, sizeof(fullpath), "%s/input.txt", DefaultDir);
    } else if (strchr(path, '/') == NULL) { // only filename
        snprintf(fullpath, sizeof(fullpath), "%s/%s", DefaultDir, path);
    } else {
        snprintf(fullpath, sizeof(fullpath), "%s", path);
    }

    printf("Saving to: %s\n", fullpath);

    FILE *f = fopen(fullpath, "w");
    if (!f) {
        perror("fopen");
        return -1;
    }

    for (int r = 0; r < m->row; ++r) {
        int off = r * m->col;
        for (int c = 0; c < m->col; ++c) {
            if (fprintf(f, "%.12g%s", m->data[off + c],
                        (c + 1 < m->col) ? " " : "") < 0) {
                fclose(f);
                fprintf(stderr, "Write error at row %d col %d\n", r, c);
                return -1;
            }
        }
        if (fputc('\n', f) == EOF) {
            fclose(f);
            fprintf(stderr, "Write error (newline)\n");
            return -1;
        }
    }

    if (fclose(f) != 0) {
        perror("fclose");
        return -1;
    }

    printf("Saved matrix [ID=%d, %dx%d] -> %s\n",
           m->ID, m->row, m->col, fullpath);
    return 0;
}

/* ============================================================
 * Save all matrices to a folder
 * ============================================================ */
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>

int SaveAllMatricesToFolder(void) {
    int count = Register_count();
    if (count == 0) {
        printf("No Matrices in memory\n");
        return -1;
    }

    char path[PATH_MAX];
    char folder[PATH_MAX * 2];

    printf("Enter the folder path where will save the matrices (empty = default): ");
    if (!fgets(path, sizeof path, stdin)) {
        printf("Input Error\n");
        return -1;
    }
    path[strcspn(path, "\r\n")] = '\0';

    int written;
    if (path[0] == '\0') {
        written = snprintf(folder, sizeof(folder), "%s", DefaultDir);
    } else {
      
        written = snprintf(folder, sizeof(folder), "%s", path);
    }

    if (written < 0 || written >= (int)sizeof(folder)) {
        fprintf(stderr, "ERROR: folder path too long in SaveAllMatricesToFolder\n");
        return -1;
    }

    if (mkdir(folder, 0777) != 0 && errno != EEXIST) {
        perror("mkdir");
        return -1;
    }

#ifdef _OPENMP
#pragma omp parallel for
#endif
    for (int id = 1; id <= count; ++id) {
        MatrixMemory *m = Register_Find(id);
        if (!m || !m->data)
            continue;

        char filename[PATH_MAX * 2];

        int w2 = snprintf(filename, sizeof(filename),
                          "%s/M%d.txt", folder, m->ID);

        if (w2 < 0 || w2 >= (int)sizeof(filename)) {
#ifdef _OPENMP
#pragma omp critical
#endif
            {
                fprintf(stderr, "Path too long for matrix ID=%d\n", m->ID);
            }
            continue;
        }

        FILE *f = fopen(filename, "w");
        if (!f) {
#ifdef _OPENMP
#pragma omp critical
#endif
            {
                perror("fopen");
                printf("Failed to save matrix ID=%d to %s\n", m->ID, filename);
            }
            continue;
        }

        for (int r = 0; r < m->row; ++r) {
            for (int c = 0; c < m->col; ++c)
                fprintf(f, "%.6f ", m->data[r * m->col + c]);
            fprintf(f, "\n");
        }

        fclose(f);

#ifdef _OPENMP
#pragma omp critical
#endif
        printf("Saved %s (ID=%d)\n", filename, m->ID);
    }

    printf("All matrices saved.\n");
    return 0;
}
/* ============================================================
 * Display one matrix
 * ============================================================ */
void DisplayMatrix(void) {
    int count = Register_count();
    if (count == 0) {
        printf("No Matrices in memory\n");
        return;
    }

    int ID, ch;
    printf("Enter Matrix ID to display it: ");
    if (scanf("%d", &ID) != 1) {
        printf("Input Error\n");
        while ((ch = getchar()) != '\n' && ch != EOF) {}
        return;
    }
    while ((ch = getchar()) != '\n' && ch != EOF) {}

    MatrixMemory *m = Register_Find(ID);
    if (!m) {
        printf("Matrix not found\n");
        return;
    }

    for (int r = 0; r < m->row; ++r) {
        for (int c = 0; c < m->col; ++c) {
            printf("% .6g ", m->data[r * m->col + c]);
        }
        putchar('\n');
    }
}

/* ============================================================
 * Display all matrices in memory
 * ============================================================ */
void DisplayAllMatrices(void) {
    int count = Register_count();
    if (count == 0) {
        printf("No Matrices in memory\n");
        return;
    }

    for (int id = 1; id <= count; ++id) {
        MatrixMemory *m = Register_Find(id);
        if (!m || !m->data)
            continue;

        printf("-----------------------------------------------------\n");
        printf("Matrix ID=%d, name=%s, size=%dx%d\n",
               m->ID, m->name, m->row, m->col);

        for (int r = 0; r < m->row; ++r) {
            for (int c = 0; c < m->col; ++c) {
                printf("% .6g ", m->data[r * m->col + c]);
            }
            putchar('\n');
        }
    }
}
