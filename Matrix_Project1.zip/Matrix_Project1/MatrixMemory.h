#ifndef __MatrixMemory_h_
#define __MatrixMemory_h_

typedef enum {
  MAT_INPUT = 0,
  MAT_OUTPUT = 1

}MatrixKind;

typedef struct {
  int ID;
  char name[32];
  int row ,col;
  double *data;
  MatrixKind kind;

}MatrixMemory;



#endif
