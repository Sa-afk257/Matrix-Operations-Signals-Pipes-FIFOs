#ifndef __REGISTERYMATRIXINMEMORY_H_
#define __REGISTERYMATRIXINMEMORY_H_

void Register_Initial(void);
int Register_Capacity(int capcityNeed);
int Register_Add(MatrixMemory *matrix);
MatrixMemory *Register_Find(int MatrixID);
int Register_Delete(int MatrixID);
void Register_FreeAll();
void Register_ListOfMatrices();
int Register_count();

#endif
