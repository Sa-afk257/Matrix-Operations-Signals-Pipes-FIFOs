#ifndef __PROCESSPOOL_H_
#define __PROCESSPOOL_H_


#define MAX_TASK_DATA 4096   // max entries for Task.row/Task.col
#define MAX_EIG_VEC   128    // max size of eigenvector we return


#include <sys/types.h>
typedef struct{
  int op;
  int R,C;  
  int IDtask;
  int elementA ,elementB;

  double row[128];
  double col[128];
  int len;
  int matrix_id;
}Task;

typedef struct{
  int R;    // Row
  int C;    // Column
  int IDtask;
  double value;
  int n;
  double vec[MAX_EIG_VEC];
}Result;


typedef struct{
  pid_t PID;
  int to_child;    
  int from_child;    
  int busy;
}worker;


int ReadWorkerProcessFromConfig();
int Pool_Initial();
int Pool_start(int ProcessWorkers);
int Create_Worker(worker *w);
void working(int read , int write);
void stop_worker(worker *w);
int pool_SendTask(int workerID ,Task *task);
int pool_ReadResult(Result *result , int *which_worker);
int pool_GetFree();
void Pool_Shutdown();
int Pool_ReconfigureFromConfig(void);

#endif
